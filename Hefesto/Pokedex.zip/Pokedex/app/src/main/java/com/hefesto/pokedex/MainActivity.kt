package com.hefesto.pokedex

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)  // OnCreate inicia uma activity //
        setContentView(R.layout.activity_main)
        shouldDisplayEmptyView(isEmpty = false) //função
    }

    fun shouldDisplayEmptyView(isEmpty: Boolean) {

        val visibility:Int = if (isEmpty) View.VISIBLE else View.GONE
//            ivFootpring.visibility = visibility
//            tvMessage.visibility = visibility
        emptyView.visibility = visibility

    } //iteração com layout imagem e texto

}

